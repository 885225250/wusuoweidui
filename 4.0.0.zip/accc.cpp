#include "accc.h"
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include<QTableView>
#include<QSqlQueryModel>

Accc::Accc(QWidget *parent) : QWidget(parent)
{
    // 加载驱动
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    // 服务器地址，本地/远程IP/域名
    db.setHostName("localhost");
    // 数据库名字
    db.setDatabaseName("ecgdata");
    // 用户名+密码
    db.setUserName("doctor3");
    db.setPassword("123456");
    // 用open打开与数据库的连接，可用close关闭
    // 如果打开成功open会返回true，否则返回false
    bool openOk = db.open();

    if (openOk)
        qDebug()<<"建立连接成功";
    else
    {
        qDebug()<<"建立连接失败";
    }

    // 查询一条信息
    if (openOk)
    {
        // query负责执行sql语句，db指定使用哪个连接
        QSqlQuery query(db);


              query.exec("SELECT * from ecg ");

              // qDebug()<<query.size();

               while(query.next())
               {
                   acgdata[i]=query.value("ecg_data").toInt();
                  // acgdata[i]=query.value("spordata").toInt();
                  // qDebug()<<query.value("Number")<<query.value("egcdata");
                    QString Number = query.value("ecg_data").toString();
                  // QString serial = query.value("serial").toString();

                 //  qDebug()<<Number<<serial;
                  // qDebug() << acgdata[i];
                    i++;
               }
       /*
               query.exec("SELECT * from ibp ");
              // qDebug()<<query.size();

               while(query.next())
               {
                   ibp2data[j]=query.value("ibp_data").toInt();

                    QString Number2 = query.value("ibp_data").toString();

                    j++;
               }
       //  qDebug() << acgdata[311];
      */

}
}





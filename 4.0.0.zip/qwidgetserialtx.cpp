#include "qwidgetserialtx.h"
#include <QtSerialPort/QSerialPortInfo>
#include <QtSerialPort/QSerialPort>
#include <QTimer>
#include <QDebug>
#include "accc.h"
#include "spo2.h"
#include "ibp2.h"
/*---------------------------Data Part-------------------------------------*/
#define  SPO2_SAMPLE_RATE  248  //test  2019  //血压
/*
static    const  unsigned  char    Spo2_DemoData[SPO2_SAMPLE_RATE]  =
{
        0x21,  0x21,  0x22,  0x22,  0x23,  0x22,  0x22,  0x21,  0x21,
        0x20,  0x20,  0x1f,  0x1e,  0x1d,  0x1c,  0x1b,  0x1b,  0x1a,
        0x19,  0x18,  0x18,  0x17,  0x16,  0x15,  0x14,  0x13,  0x12,
        0x11,  0x11,  0x10,  0x10,  0x0f,  0x0f,  0x0e,  0x0d,  0x0c,
        0x0c,  0x0b,  0x0a,  0x09,  0x09,  0x08,  0x07,  0x06,  0x06,
        0x05,  0x05,  0x04,  0x04,  0x03,  0x03,  0x02,  0x02,  0x01,
        0x01,  0x00,  0x00,  0x00,  0x00,  0x00,  0x00,  0x00,  0x00,
        0x00,  0x01,  0x03,  0x06,  0x0a,  0x0e,  0x13,  0x18,  0x1d,
        0x23,  0x28,  0x2d,  0x32,  0x37,  0x3b,  0x40,  0x44,  0x49,
        0x4d,  0x51,  0x54,  0x57,  0x58,  0x5a,  0x5a,  0x5a,  0x59,
        0x59,  0x57,  0x55,  0x52,  0x50,  0x4c,  0x49,  0x45,  0x42,
        0x3e,  0x3b,  0x37,  0x34,  0x31,  0x2f,  0x2c,  0x29,  0x26,
        0x24,  0x22,  0x20,  0x1f,  0x1f,  0x1e,  0x1e,  0x1d,  0x1d,
        0x1e,  0x1f,  0x20,  0x21,  0x21,  0x22,  0x22,  0x23,  0x22,
        0x22,  0x21,  0x21,  0x20,  0x20,  0x1f,  0x1e,  0x1d,  0x1c,
        0x1b,  0x1b,  0x1a,  0x19,  0x18,  0x18,  0x17,  0x16,  0x15,
        0x14,  0x13,  0x12,  0x11,  0x11,  0x10,  0x10,  0x0f,  0x0f,
        0x0e,  0x0d,  0x0c,  0x0c,  0x0b,  0x0a,  0x09,  0x09,  0x08,
        0x07,  0x06,  0x06,  0x05,  0x05,  0x04,  0x04,  0x03,  0x03,
        0x02,  0x02,  0x01,  0x01,  0x00,  0x00,  0x00,  0x00,  0x00,
        0x00,  0x00,  0x00,  0x00,  0x01,  0x03,  0x06,  0x0a,  0x0e,
        0x13,  0x18,  0x1d,  0x23,  0x28,  0x2d,  0x32,  0x37,  0x3b,
        0x40,  0x44,  0x49,  0x4d,  0x51,  0x54,  0x57,  0x58,  0x5a,
        0x5a,  0x5a,  0x59,  0x59,  0x57,  0x55,  0x52,  0x50,  0x4c,
        0x49,  0x45,  0x42,  0x3e,  0x3b,  0x37,  0x34,  0x31,  0x2f,
        0x2c,  0x29,  0x26,  0x24,  0x22,  0x20,  0x1f,  0x1f,  0x1e,
        0x1e,  0x1d,  0x1d,  0x1e,  0x1f,  0x20,  0x21,  0x21,  0x22,
        0x22,  0x23,  0x22,  0x22,  0x21,
};*/

#define ECG500HZ 500//心电图
/*
static  const  unsigned  short  int  Ecg1_500DemoData[ECG500HZ]  =  {
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,  2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2008, 2016, 2016, 2016, 2024, 2032, 2048,
2064, 2064, 2064, 2072, 2080, 2080, 2080, 2088, 2096, 2104,
2112, 2112, 2112, 2112, 2112, 2112, 2104, 2096, 2088,
2080, 2080, 2080, 2072, 2064, 2064, 2064, 2048, 2032, 2032,
2032, 2016, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 1992, 1984, 1976,
1968, 1960, 1952, 1944, 1936, 1944, 1952, 2016, 2080, 2136,
2192, 2256, 2320, 2376, 2432, 2488, 2544, 2568, 2592, 2536,
2480, 2424, 2368, 2304, 2240, 2184, 2128, 2072, 2016, 1968,
1920, 1928, 1936, 1944, 1952, 1960, 1968, 1984, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2008, 2016, 2024, 2032, 2032,
2032, 2048, 2064, 2064, 2064, 2072, 2080, 2088, 2096, 2104,
2112, 2112, 2112, 2120, 2128, 2136, 2144, 2152, 2160, 2160,
2160, 2160, 2160, 2168, 2176, 2176, 2176, 2184, 2192,
2192, 2192, 2192, 2200, 2208, 2208, 2208, 2208, 2208, 2208,
2208, 2200, 2192, 2192, 2192, 2184, 2176, 2176, 2176, 2168,
2160, 2160, 2160, 2144, 2128, 2128, 2128, 2128, 2128, 2112,
2096, 2088, 2080, 2072, 2064, 2064, 2064, 2048, 2032, 2024,
2016, 2016, 2016, 2008, 2000, 2000, 2000, 2000, 2000,
2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000
};
*/
#define IBP_SAMPLE_RATE 125//血氧
/*
const unsigned short int Ibp2_DemoData[IBP_SAMPLE_RATE] =
{
  0x0f, 0x10, 0x10, 0x11, 0x12, 0x12, 0x12, 0x13, 0x13,
  0x14, 0x14, 0x14, 0x14, 0x15, 0x17, 0x17, 0x17, 0x18,
  0x18, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x19, 0x1a, 0x1a,
  0x1b, 0x1b, 0x1b, 0x1c, 0x1c, 0x1b, 0x1b, 0x1a, 0x1a,
  0x1a, 0x19, 0x19, 0x18, 0x18, 0x18, 0x17, 0x17, 0x15,
  0x15, 0x15, 0x14, 0x15, 0x14, 0x14, 0x14, 0x15, 0x15,
  0x14, 0x14, 0x15, 0x14, 0x14, 0x14, 0x15, 0x17, 0x17,
  0x17, 0x17, 0x18, 0x18, 0x19, 0x19, 0x19, 0x1a, 0x1b,
  0x1c, 0x1d, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x24,
  0x24, 0x26, 0x26, 0x26, 0x26, 0x24, 0x23, 0x23, 0x23,
  0x23, 0x22, 0x21, 0x20, 0x1d, 0x1d, 0x1c, 0x1c, 0x1c,
  0x1c, 0x1c, 0x1c, 0x1c, 0x1b, 0x1c, 0x1b, 0x1a, 0x1a,
  0x19, 0x18, 0x17, 0x15, 0x14, 0x12, 0x12, 0x11, 0x10,
  0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f
};*/

/*---------------------------Function Part-------------------------------------*/
QWidgetSerialTx::QWidgetSerialTx(QWidget *parent, int type) : QWidget(parent)
{


    // 创建定时器
    this->timer = new QTimer();
    this->makeEcgdata();
    this->makeSpo2data();
    this->makeIbp2data();
    // 定时器溢出信号与发送ecg数据包函数关联

   // connect(this->timer, &QTimer::timeout, this, &QWidgetSerialTx::sendIdpPkg);

    if(type == 0){
        this->serialEcgInit();
        connect(this->timer, &QTimer::timeout, this, &QWidgetSerialTx::sendEcgPkg);


    }
    if(type == 1){
        this->serialSpoInit();
        connect(this->timer, &QTimer::timeout, this, &QWidgetSerialTx::sendSpoPkg);
    }
    if(type == 2){
        this->serialIbpInit();
        connect(this->timer, &QTimer::timeout, this, &QWidgetSerialTx::sendIdpPkg);
    }
   // connect(this->timer, &QTimer::timeout, this, &QWidgetSerialTx::sendSpoPkg);
    // 启动定时器
    this->timer->start(3); //调试用500ms，正常使用2ms

}

unsigned int QWidgetSerialTx::getEcg2Data()
{
    this->index += 1;
    if(this->index >= 500)
        this->index = 0;
   // return Ecg1_500DemoData[this->index]; //返回采样点数据
  return arr[this->index];
 //  return acgdata[this->index];

}

unsigned int QWidgetSerialTx::getSpo2Data()
{
    this->index += 1;
    if(this->index >= SPO2_SAMPLE_RATE)
        this->index = 0;
    //return Spo2_DemoData[this->index]; //返回采样点数据
    return Spo2[this->index];
}

unsigned int QWidgetSerialTx::getIdp2Data()
{
    this->index += 1;
    if(this->index >= IBP_SAMPLE_RATE)
        this->index = 0;
   // return Ibp2_DemoData[this->index]; //返回采样点数据
    return Ibp2[this->index];
}

void QWidgetSerialTx::sendEcgPkg()
{
    char dataBuf[10];
    unsigned int ecgData[3] ;
    int i;
    char byteH, byteL;

    // 取心电数据/获取ADC数据
    ecgData[0] = this->getEcg2Data();
    ecgData[1] = ecgData[0];
    ecgData[2] = ecgData[0];

    // 数据包格式：ID + 数据头 + 数据 + 校验
    // 数据打包
    dataBuf[0] = 0x08;
    dataBuf[1] = 0x80; // 最高位总是1
    // 添加数据
    for(i = 0; i < 3; i++)
    {
        byteH = (char)((ecgData[i]&0xFF00) >> 8);
        byteL = (char)(ecgData[i]&0xFF);
        // 字节最高位存入数据头
        dataBuf[1] = dataBuf[1] | ((byteH&0x80) >> (7 - i*2));
        dataBuf[1] = dataBuf[1] | ((byteL&0x80) >> (7 - i*2 - 1));
        // 添加数据
        dataBuf[2 + i*2] = 0x80 | byteH;
        dataBuf[2 + i*2 + 1] = 0x80 | byteL;
    }
    dataBuf[8] = 0x80; //数据状态字段暂时不用
    dataBuf[9] = 0xFF; //暂时不用
    qDebug()<<"ecgTx:"<<"ecg1="<<ecgData[0]<<"ecg2="<<ecgData[1]<<"ecg3="<<ecgData[2];
    this->com->write(dataBuf, sizeof(dataBuf));
}

void QWidgetSerialTx::sendSpoPkg()
{
    char dataBuf[4];
    unsigned char spoData = 0;

    // 取血氧数据/获取ADC数据
    spoData = this->getSpo2Data();


    // 数据包格式：ID + 数据头 + 数据 + 校验
    // 数据打包
    dataBuf[0] = 0x09;
    dataBuf[1] = 0x80; // 最高位总是1
    // 添加数据

    // 字节最高位存入数据头
    dataBuf[1] = dataBuf[1] | ((spoData&0x80) >> 7);
    // 添加数据
    dataBuf[2] = 0x80 | spoData;

    dataBuf[3] = 0xFF; //暂时不用
    qDebug()<<"spoTx:"<<spoData;
    this->com->write(dataBuf, sizeof(dataBuf));

}

void QWidgetSerialTx::sendIdpPkg()
{
    char dataBuf[4];
    unsigned char idpData = 0;

    // 取血氧数据/获取ADC数据
    idpData = this->getIdp2Data();


    // 数据包格式：ID + 数据头 + 数据 + 校验
    // 数据打包
    dataBuf[0] = 0x0a;
    dataBuf[1] = 0x80; // 最高位总是1
    // 添加数据

    // 字节最高位存入数据头
    dataBuf[1] = dataBuf[1] | ((idpData&0x80) >> 7);
    // 添加数据
    dataBuf[2] = 0x80 | idpData;

    dataBuf[3] = 0xFF; //暂时不用
    qDebug()<<"idpTx:"<<idpData;
    this->com->write(dataBuf, sizeof(dataBuf));
}
//
int QWidgetSerialTx::serialEcgInit(){
    // 查看设备串口信息
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts()){
        qDebug() << "Name : " << info.portName();
        qDebug() << "Description : " << info.description();
        qDebug() << "Manufacturer: " << info.manufacturer();
        qDebug() << "Serial Number: " << info.serialNumber();
    }

    // 创建串口对象
    this->com = new QSerialPort();
    // 打开串口
    this->com->setPortName("COM1");
    // 尝试打开
    if(!this->com->open(QIODevice::ReadWrite)){
       qDebug()<<"open serial error"<<this->com->portName();
       return -1;
    }
    else
       qDebug()<<"open serial success";

    // 串口参数配置
    this->com->setBaudRate(QSerialPort::Baud115200);
    this->com->setDataBits(QSerialPort::Data8);
    this->com->setFlowControl(QSerialPort::NoFlowControl);
    this->com->setParity(QSerialPort::NoParity);
    this->com->setStopBits(QSerialPort::OneStop);

    return 0;
}

int QWidgetSerialTx::serialSpoInit(){
    // 查看设备串口信息
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts()){
        qDebug() << "Name : " << info.portName();
        qDebug() << "Description : " << info.description();
        qDebug() << "Manufacturer: " << info.manufacturer();
        qDebug() << "Serial Number: " << info.serialNumber();
    }

    // 创建串口对象
    this->com = new QSerialPort();
    // 打开串口
    this->com->setPortName("COM7");
    // 尝试打开
    if(!this->com->open(QIODevice::ReadWrite)){
       qDebug()<<"open serial error"<<this->com->portName();
       return -1;
    }
    else
       qDebug()<<"open serial success";

    // 串口参数配置
    this->com->setBaudRate(QSerialPort::Baud115200);
    this->com->setDataBits(QSerialPort::Data8);
    this->com->setFlowControl(QSerialPort::NoFlowControl);
    this->com->setParity(QSerialPort::NoParity);
    this->com->setStopBits(QSerialPort::OneStop);

    return 0;
}

int QWidgetSerialTx::serialIbpInit(){
    // 查看设备串口信息
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts()){
        qDebug() << "Name : " << info.portName();
        qDebug() << "Description : " << info.description();
        qDebug() << "Manufacturer: " << info.manufacturer();
        qDebug() << "Serial Number: " << info.serialNumber();
    }

    // 创建串口对象
    this->com = new QSerialPort();
    // 打开串口
    this->com->setPortName("COM4");
    // 尝试打开
    if(!this->com->open(QIODevice::ReadWrite)){
       qDebug()<<"open serial error"<<this->com->portName();
       return -1;
    }
    else
       qDebug()<<"open serial success";

    // 串口参数配置
    this->com->setBaudRate(QSerialPort::Baud115200);
    this->com->setDataBits(QSerialPort::Data8);
    this->com->setFlowControl(QSerialPort::NoFlowControl);
    this->com->setParity(QSerialPort::NoParity);
    this->com->setStopBits(QSerialPort::OneStop);

    return 0;
}
int QWidgetSerialTx::makeEcgdata(){

     Accc *all = new  Accc();
     // this->accc = new Accc(this);//

      int j=0;
     while(j<500)
     {
         arr[j]= all->acgdata[j];
         //arr[j]=this->accc->acgdata[j+1];
         // qDebug()<<all->acgdata[j];
       //  qDebug()<<"********************************"<<arr[j];
         j+=1;
     }
      qDebug()<<arr[309];
}
int QWidgetSerialTx::makeSpo2data(){

     spo2 *all2 = new  spo2();
     // this->accc = new Accc(this);//

      int c=0;
     while(c<248)
     {
         Spo2[c]= all2->spo2data[c];
       qDebug()<<"********************************"<<all2->spo2data[c];
         c+=1;
     }
     // qDebug()<<spo2data[100];
}
int QWidgetSerialTx::makeIbp2data(){

     ibp2 *all3 = new  ibp2();
     // this->accc = new Accc(this);//

      int c=0;
     while(c<125)
     {
         Ibp2[c]= all3->ibp2data[c];
       qDebug()<<"********************************"<<all3->ibp2data[c];
         c+=1;
     }
     // qDebug()<<spo2data[100];
}



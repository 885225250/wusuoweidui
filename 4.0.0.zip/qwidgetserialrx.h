#ifndef QWIDGETSERIALRX_H
#define QWIDGETSERIALRX_H

#include <QObject>
#include <QWidget>
#include <QtSerialPort/QSerialPortInfo>
#include <QtSerialPort/QSerialPort>

class QWidgetSerialRx : public QWidget
{
    Q_OBJECT
public:
    QSerialPort *com;
    char status = 0;
    char pkgDataCnt;
    char pkgDataHead;
    char pkgDataSign;
    unsigned char pkgEcgData[7];
    unsigned char pkgIdpData;
    unsigned char pkgSpoData;
    char pkgDataCrc;
    int ecg1, ecg2, ecg3;
    unsigned char spo, idp;
    int cntEcg = 0;
    int cntIdp = 0;
    int cntSpo = 0;
    int index = 0;
    explicit QWidgetSerialRx(QWidget *parent, int type);
    int serialEcgInit();
    int serialIbpInit();
    int serialSpoInit();
    void serialRx();
    void rxDataHandle(unsigned char data);
    void sendData();
    void sendIbpData();
    void sendEcgData();
    void sendSpoData();

signals:
    void rxDataSignal(int data);
};

#endif // QWIDGETSERIALRX_H

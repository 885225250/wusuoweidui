#ifndef QWIDGETDEMO_H
#define QWIDGETDEMO_H

#include <QWidget>

class QWidgetDemo : public QWidget
{
    Q_OBJECT
public:
    QString *username;
    QString *password;
    explicit QWidgetDemo(QWidget *parent = nullptr);

signals:

};

#endif // QWIDGETDEMO_H

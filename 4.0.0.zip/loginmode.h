#ifndef LOGINMODE_H
#define LOGINMODE_H

#include <QWidget>

class LogInMode : public QWidget
{
    Q_OBJECT
public:
    explicit LogInMode(QWidget *parent = nullptr);

signals:

};

#endif // LOGINMODE_H

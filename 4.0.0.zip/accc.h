#ifndef ACCC_H
#define ACCC_H

#include <QWidget>

class Accc : public QWidget
{
    Q_OBJECT
public:
    int acgdata[500];

    int i = 0;
    int j = 0;
    explicit Accc(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // ACCC_H

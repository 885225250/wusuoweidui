#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("登陆界面");

    //ui->hori->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
    ui->lineEdit->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
    this->resize(420,300);
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
   ui->pushButton->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
  ui->pushButton_2->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
  qwe = new ChildWidget();
  wer = new PatientMessage();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{

    QString username = ui->lineEdit->text();
    QString password = ui->lineEdit_2->text();
       if(username == "doctor3" && password == "123456")
       {
           ui->label->setText("登陆成功");

           this->close();
               qwe->show();
             wer->show();

       }
       else
       {
           if(username == "" || password == "")
           {
               ui->label->setText("用户名密码不能为空");
           }
           else{

            ui->label->setText("登陆失败，用户名或者密码错误");
            }
       }
}

void MainWindow::on_pushButton_2_clicked()
{
    this->close();
}

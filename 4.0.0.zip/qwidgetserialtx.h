#ifndef QWIDGETSERIALTX_H
#define QWIDGETSERIALTX_H

#include <QWidget>
#include <QtSerialPort/QSerialPort>
#include <QTimer>

class QWidgetSerialTx : public QWidget
{
    Q_OBJECT
public:
    QSerialPort *com;
    QTimer *timer;
    int index = 0;
     int  arr[500];
     int Spo2[248];
     int Ibp2[248];
    explicit QWidgetSerialTx(QWidget *parent, int type);

    int serialEcgInit(void);
    int serialIbpInit(void);
    int serialSpoInit(void);
    void sendEcgPkg();
    void sendSpoPkg();
    void sendIdpPkg();
    unsigned int getEcg2Data();
    unsigned int getSpo2Data();
    unsigned int getIdp2Data();
    int makeEcgdata();
    int makeSpo2data();
    int makeIbp2data();
signals:

};

#endif // QWIDGETSERIALTX_H

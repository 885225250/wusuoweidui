#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>

//#include "layoutDemo.h"
#include "qwidgetdraw.h"
#include "qwidgetserialtx.h"
#include "qwidgetserialrx.h"
#include "mainwindow.h"




#if 1
int main(int argc, char * argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();

    return a.exec();
}

# endif























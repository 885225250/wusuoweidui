#ifndef LAYOUTDEMO_H
#define LAYOUTDEMO_H


void layoutDemo0(void);
void layoutDemo1(void);
void layoutDemo2(void);


#endif // LAYOUTDEMO_H

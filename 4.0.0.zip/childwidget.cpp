#include "childwidget.h"
#include "childwidget.h"
#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include "mainwindow.h"
//#include "layoutDemo.h"
#include "qwidgetdraw.h"
#include "qwidgetserialtx.h"
#include "qwidgetserialrx.h"


ChildWidget::ChildWidget(QWidget *parent) : QWidget(parent)
{

    QWidget * mainWin = new QWidget();
    QTimer *timer;
    //QVBoxLayout *vlayoutMain = new QVBoxLayout();
    timer = new QTimer(mainWin);
    timer->start(10); //单位是毫秒
    //mainWin->resize(800,480);
    // 左侧三块儿水平label
    //心电波形图
    QWidgetDraw *drawEcg = new QWidgetDraw(mainWin);
    QWidgetSerialTx *serialEcgTx = new QWidgetSerialTx(mainWin, 0);
    QWidgetSerialRx *serialEcgRx = new QWidgetSerialRx(mainWin, 0);
    mainWin->connect(timer, &QTimer::timeout, serialEcgRx, &QWidgetSerialRx::sendEcgData);
    mainWin->connect(serialEcgRx, &QWidgetSerialRx::rxDataSignal, drawEcg, &QWidgetDraw::refreshEcgFromData);
   // vlayoutMain->addWidget(drawEcg);
    //设置界面显示内容
    drawEcg->setLabelText("ecg");
    drawEcg->setStyleSheet("background-color:black; color:white; font-family:Microsoft TaHei; font-size:15px");
    //血氧波形图
    QWidgetDraw *drawSpo = new QWidgetDraw(mainWin);
    QWidgetSerialTx *serialSpoTx = new QWidgetSerialTx(mainWin, 1);
    QWidgetSerialRx *serialSpoRx = new QWidgetSerialRx(mainWin, 1);
    mainWin->connect(timer, &QTimer::timeout, serialSpoRx, &QWidgetSerialRx::sendSpoData);
    mainWin->connect(serialSpoRx, &QWidgetSerialRx::rxDataSignal, drawSpo, &QWidgetDraw::refreshSpoFromData);
   // vlayoutMain->addWidget(drawSpo);
    drawSpo->setLabelText("Spo");
    drawSpo->setStyleSheet("background-color:black; color:white; font-family:Microsoft TaHei; font-size:15px");
    //血压波形图绘图控件和数据发送部分
    QWidgetDraw *drawIbp = new QWidgetDraw(mainWin);
    QWidgetSerialTx *serialIbpTx = new QWidgetSerialTx(mainWin, 2);
    QWidgetSerialRx *serialIbpRx = new QWidgetSerialRx(mainWin, 2);
    mainWin->connect(timer, &QTimer::timeout, serialIbpRx, &QWidgetSerialRx::sendIbpData);
    mainWin->connect(serialIbpRx, &QWidgetSerialRx::rxDataSignal, drawIbp, &QWidgetDraw::refreshIbpFromData);
   // vlayoutMain->addWidget(drawIbp);
    drawIbp->setLabelText("Ibp");
    drawIbp->setStyleSheet("background-color:black; color:white; font-family:Microsoft TaHei; font-size:15px");
    //绘图部分的策略
    drawEcg->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
    drawSpo->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
    drawIbp->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);


    //新建右边三个界面，显示基本信息
    QWidget *hlayout1 = new QWidget();
    QWidget *hlayout2 = new QWidget();
    QWidget *hlayout3 = new QWidget();
    //新建左边三个界面，显示三种波形名称
    QWidget *hlayout4 = new QWidget();
    QWidget *hlayout5 = new QWidget();
    QWidget *hlayout6 = new QWidget();
    //建立一个垂直布局用来放置右边三个三个界面
    QVBoxLayout *vlayout1 = new QVBoxLayout();
    //设置右边三个界面的显示
    //QLabel *label1 = new QLabel();
    //label1->setText("80");
    //label1->setStyleSheet("color:green;font-size:40px");
    // label1->setParent(hlayout1);
    hlayout1->setStyleSheet("background-color:black");
    //这里面有两个布局，需要加进去，形成一个总体布局
    QHBoxLayout *hlayout1_0 = new QHBoxLayout();
    QWidget *hlayout1_1 = new QWidget();
    QWidget *hlayout1_2 = new QWidget();
    hlayout1_1->setStyleSheet("background-color:black");
    hlayout1_2->setStyleSheet("background-color:black");
    QLabel *label1_1 = new QLabel();
    QLabel *label1_2 = new QLabel();

    label1_1->setText("HR                               ");
    label1_1->setStyleSheet("background-color:grey;color:white;font-size:20px");
    label1_1->setParent(hlayout1_1);
    QLabel *label1_1_1 = new QLabel();
    QLabel *label1_1_2 = new QLabel();

    label1_1_1->setText("80");
    label1_1_1->setStyleSheet("color:green;font-size:60px");
    label1_1_1->setParent(hlayout1_1);
    label1_1_1->setGeometry(60,50,110,70);

    label1_1_2->setText("bpm");
    label1_1_2->setStyleSheet("color:green;font-size:15px");
    label1_1_2->setParent(hlayout1_1);
    label1_1_2->setGeometry(220,20,100,40);

    label1_2->setText("ST                              ");
    label1_2->setStyleSheet("color:white;background-color:grey;font-size:20px");
    label1_2->setParent(hlayout1_2);
    QLabel *label1_2_1 = new QLabel();
    QLabel *label1_2_2 = new QLabel();
    QLabel *label1_2_3 = new QLabel();
    label1_2_1->setText("ST1-?-");
    label1_2_1->setStyleSheet("color:green;font-size:25px");
    label1_2_1->setParent(hlayout1_2);
    label1_2_1->setGeometry(80,20,110,30);

    label1_2_2->setText("ST2-?-");
    label1_2_2->setStyleSheet("color:green;font-size:25px");
    label1_2_2->setParent(hlayout1_2);
    label1_2_2->setGeometry(80,55,110,30);

    label1_2_3->setText("PVCs-?-");
    label1_2_3->setStyleSheet("color:green;font-size:25px");
    label1_2_3->setParent(hlayout1_2);
    label1_2_3->setGeometry(75,85,130,30);


    hlayout1_0->addWidget(hlayout1_1);
    hlayout1_0->addWidget(hlayout1_2);
    hlayout1->setLayout(hlayout1_0);
    //设置第二行显示内容
    QLabel *label2 = new QLabel();
    label2->setText("NIBP                                                                    ");
    label2->setStyleSheet("color:white;background-color:grey;font-size:20px");
    label2->setParent(hlayout2);
    hlayout2->setStyleSheet("background-color:black");
    QLabel *label2_1 = new QLabel();
    label2_1->setText("00:00:00              mmHg");
    label2_1->setStyleSheet("color:green;font-size:25px");
    label2_1->setParent(hlayout1_2);
    label2_1->setGeometry(80,55,110,30);

    hlayout3->setStyleSheet("background-color:black");
    //第三行也是一行两个布局
    QHBoxLayout *hlayout3_0 = new QHBoxLayout();
    QWidget *hlayout3_1 = new QWidget();
    QWidget *hlayout3_2 = new QWidget();
    hlayout3_1->setStyleSheet("background-color:black");
    hlayout3_2->setStyleSheet("background-color:black");
    QLabel *label3_1 = new QLabel();
    QLabel *label3_2 = new QLabel();

    label3_1->setText("SpO2                              ");
    label3_1->setStyleSheet("color:white;background-color:grey;font-size:20px");
    label3_1->setParent(hlayout3_1);

    label3_2->setText("TEMP                                ");
    label3_2->setStyleSheet("color:white;background-color:grey;font-size:20px");
    label3_2->setParent(hlayout3_2);

    hlayout3_0->addWidget(hlayout3_1);
    hlayout3_0->addWidget(hlayout3_2);
    hlayout3->setLayout(hlayout3_0);
    //设置you'bia右边显示的第四行
    QWidget *hlayout4add = new QWidget();
    hlayout4add->setStyleSheet("background-color:black");

    QHBoxLayout *hlayout4_0 = new QHBoxLayout();
    QWidget *hlayout4_1 = new QWidget();
    QWidget *hlayout4_2 = new QWidget();
    hlayout4_1->setStyleSheet("background-color:black");
    hlayout4_2->setStyleSheet("background-color:black");
    QLabel *label4_1 = new QLabel();
    QLabel *label4_2 = new QLabel();

    label4_1->setText("RESP                                 ");
    label4_1->setStyleSheet("color:white;background-color:grey;font-size:20px");
    label4_1->setParent(hlayout4_1);

    label4_2->setText("CO2                                      ");
    label4_2->setStyleSheet("color:white;background-color:grey;font-size:20px");
    label4_2->setParent(hlayout4_2);

    hlayout4_0->addWidget(hlayout4_1);
    hlayout4_0->addWidget(hlayout4_2);
    hlayout4add->setLayout(hlayout4_0);

    //将右边的三个窗口加到右边的主界面上
    vlayout1->addWidget(hlayout1);
    vlayout1->addWidget(hlayout2);
    vlayout1->addWidget(hlayout3);
    vlayout1->addWidget(hlayout4add);







    //设置左边三个波形的名称
    QLabel *label4 = new QLabel();
    label4->setText("ECGII      x1                                                                                                 ");
    label4->setStyleSheet("color:white;background-color:grey;font-size:30px");
    label4->setParent(hlayout4);
    hlayout4->setStyleSheet("background-color:black");

    QLabel *label5 = new QLabel();
    label5->setText("SPO2                                                                                                          ");
    label5->setStyleSheet("color:white;background-color:grey;font-size:30px");
    label5->setParent(hlayout5);
    hlayout5->setStyleSheet("background-color:black");

    QLabel *label6 = new QLabel();
    label6->setText("RESP       x1                                                                                                 ");
    label6->setStyleSheet("color:white;background-color:grey;font-size:30px");
    label6->setParent(hlayout6);
    hlayout6->setStyleSheet("background-color:black");
    //画出三种波形
    //     QWidget  *drawWidgetEcg  = new QWidget();
    //     QWidget  *drawWidgetEcgI = new QWidget();
    //     QWidget  *drawWidgetEcgII= new QWidget();
    //设置左边的布局，将左边的布局配置好
    QVBoxLayout *layoutMain = new QVBoxLayout();

    layoutMain->addWidget(hlayout4);//心电图波形
    layoutMain->addWidget(drawEcg);//心电图波形
    layoutMain->addWidget(hlayout5);//心电图波形
    layoutMain->addWidget(drawSpo);//血压
    layoutMain->addWidget(hlayout6);//心电图波形
    layoutMain->addWidget(drawIbp);//血氧

    layoutMain->setStretchFactor(hlayout4,1);
    layoutMain->setStretchFactor(hlayout5,1);
    layoutMain->setStretchFactor(hlayout6,1);
    layoutMain->setStretchFactor(drawEcg,5);
    layoutMain->setStretchFactor(drawSpo,5);
    layoutMain->setStretchFactor(drawIbp,5);
    //设置总体显示的水平布局
    //将两个垂直布局放在同一个水平总布局中国
    //设置拉伸因子
    QHBoxLayout *main = new QHBoxLayout();
    main->addLayout(layoutMain);
    main->addLayout(vlayout1);
    main->setStretchFactor(layoutMain,2);
    main->setStretchFactor(vlayout1,1);
    //设立显示主窗口，将总布局加入主窗口中

    mainWin->setStyleSheet("background-color:black");
    mainWin->setWindowTitle("无所谓队");
    mainWin->setLayout(main);
    mainWin->resize(1500, 600);
    QHBoxLayout *ll = new QHBoxLayout();
    ll->addWidget(mainWin);
    this->setLayout(ll);
     this->setWindowTitle("基于新冠疫情的云监护仪");
    this->resize(2000,1000);
}

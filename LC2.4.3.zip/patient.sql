/*
MySQL Data Transfer
Source Host: localhost
Source Database: d1
Target Host: localhost
Target Database: d1
Date: 2020/7/25 2:35:15
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for patient
-- ----------------------------
CREATE TABLE `patient` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(5) default NULL,
  `sex` varchar(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `patient` VALUES ('1001', 'qwe', '男');
INSERT INTO `patient` VALUES ('1002', 'bbb', '女');
INSERT INTO `patient` VALUES ('1003', 'cc', '女');

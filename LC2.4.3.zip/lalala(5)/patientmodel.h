#ifndef PATIENTMODEL_H
#define PATIENTMODEL_H


#include<QSqlQueryModel>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include<QTableView>
#include<QSqlQueryModel>
#include <QApplication>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include<QTableView>
#include<QSqlQueryModel>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include<QTableView>
#include<QSqlQueryModel>


class Patientmodel:public QSqlQueryModel
{
public:
    Patientmodel()
    {
        this->setQuery( "select * from patient");
    }
    Qt::ItemFlags flags(const QModelIndex &index)const override
    {
      //  qDebug()<<" i am here"<<index.row()<<index.column();
    Qt::ItemFlags flags =QSqlQueryModel::flags(index);
    if(index.column()==1||index.column()==2)
    flags |=Qt::ItemIsEditable;//数据是可以编辑的但是还没有会写
    return flags;
    }


    bool setName (int id, QString name)
    {   bool ok;
        QSqlQuery query;
        query.prepare("update patient set name =? where id =?");
        query.addBindValue(name);
        query.addBindValue(id);
        ok = query.exec();
        return ok;


    }
    bool setSex (int id, QString sex)
    {   //bool ok;
        QSqlQuery query;
        query.prepare("update patient set sex =? where id =?");
        query.addBindValue(sex);
        query.addBindValue(id);
        //ok = query.exec();
        //return ok;
        return query.exec();

    }
    bool setData(const QModelIndex &index,const QVariant &value, int) override
    {
        if(index.column()<1||index.column()>2)
            return false;
        //获取当前列当前行，用sql更新数据
        //获取当前第一个单元格对象
    QModelIndex primaryKeyIndex = QSqlQueryModel::index(index.row(),0);
    //从单元格对象得到第零列的内容
    int id = this->data(primaryKeyIndex).toInt();
    qDebug()<<"id:"<<id;
    bool ok =false;
    if (index.column()==1)
    {
        //更新姓名

        qDebug()<<"更新姓名";
        ok=setName(id,value.toString());
    }else if (index.column()==2)
    {
         //更新性别
         qDebug()<<"更新性别";
         ok=setSex(id,value.toString());
    }else
    {
        qDebug()<<"错误";
    }
    if(ok)
    {
    this->setQuery("select * from patient");
    }
                return ok;
    }
};
#endif // PATIENTMODEL_H

#include "patientmessage.h"
#include "patientmodel.h"
#include <QApplication>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include<QTableView>
#include<QSqlQueryModel>
#include <QHBoxLayout>
#include <mainwindow.h>
 #include <QTableWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QTimer>

PatientMessage::PatientMessage(QWidget *parent) : QWidget(parent)
{
    // 加载驱动
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    // 服务器地址，本地/远程IP/域名
    db.setHostName("localhost");
    // 数据库名字
    db.setDatabaseName("ecgdata");
    // 用户名+密码
    db.setUserName("doctor3");
    db.setPassword("123456");
    // 用open打开与数据库的连接，可用close关闭
    // 如果打开成功open会返回true，否则返回false
    bool openOk = db.open();

    if (openOk)
        qDebug()<<"建立连接成功";
    else
    {
        qDebug()<<"建立连接失败";
    }

    // 查询一条信息
    if (openOk)
    {
        // query负责执行sql语句，db指定使用哪个连接
        QSqlQuery query(db);
/*************************************************************
 * 以上代码
 */
        // 执行sql语句
        // 方法1
//        qDebug()<<"方法1";
//        query.exec("SELECT * from doctor WHERE uid = 'doctor1'");
        // 方法2
//        qDebug()<<"方法2";
//        QString userid = "doctor1";
//        QString sql = "SELECT * FROM doctor WHERE uid = '";
//        sql += userid;
//        sql += "'";
//        qDebug()<<sql;
//        query.exec(sql);
        // 方法3，可读性会更好
        /*
        qDebug()<<"方法3";
        QString userid = "doctor1";

        query.prepare("SELECT * FROM doctor");
//        query.bindValue(":id", "doctor1");
        query.bindValue(":id", userid); //用变量替换":uid", 注意变量上没有''
        query.exec();
        // 打印返回结果
        qDebug()<<query.size();
        */
        //query负责执行sql语句，db指定那个连接

               query.exec("SELECT * from device ");
               qDebug()<<query.size();

               while(query.next())
               {
                   qDebug()<<query.value("device_id")<<query.value("serial")<<query.value("refresh");
                    QString device_id = query.value("device_id").toString();
                   QString serial = query.value("serial").toString();
                   // qlonglong mobile = query.value("mobile").toULongLong();
                    qDebug()<<device_id<<serial;
               }
        while(query.next())//遍历返回的数据表
        {
            qDebug()<<query.value("name")<<query.value("mobile");
            QString name = query.value("name").toString(); // 获取名字字段
            qlonglong mobile = query.value("mobile").toULongLong();
            qDebug()<<name<<mobile; //获取手机号码字段
        }

        if (query.size() < 0)
        {
            qDebug()<<query.lastError();
        }

        bool queryOk;
        // 工作站从数据库读取数据
        query.prepare("SELECT * FROM sample WHERE time > :start and time < :end");
        query.bindValue(":start", "2020-07-22 11:00:00");
        query.bindValue(":end", "2020-07-22 12:00:00");

        queryOk = query.exec();
        if(queryOk)
        {
//            while(query.next())
//            {
//                QByteArray waveData = query.value("value").toByteArray();
//                // todo, 画波形
//                qDebug()<<waveData;
//            }
            qDebug("得到波形数据");
        }else
        {
            qDebug()<<"读波形错误："<<query.lastError();
        }

        /*
 * 以上代码应运行于工作站
*8888888888888888888888888888888888888888888888
* 以下代码运行于设备端
*/

        // 获取当前设备是否已在设备表中
        query.prepare("SELECT * from device "
                      "WHERE serial = :serial");
        query.bindValue(":serial", "DEV-007");

        int dev_id;
        if(query.exec())
        {
            qDebug()<<"size"<<query.size();
            if(query.size() > 0)
            {
                query.next();
                qDebug()<<"设备已存在";
                dev_id = query.value("dev_id").toInt();
                qDebug()<<"当前设备编号："<<dev_id;
            }
            else
            {
                query.prepare("INSERT INTO device (serial)"
                              "VALUES (:serial)");
                query.bindValue(":serial", "DEV-007");
                if (!query.exec())
                {
                    qDebug("设备注册失败！");
                }
                else
                {
                    qDebug("设备注册成功！");
                }
            }
        }else
        {
            qDebug()<<"查看设备错误";
        }

        // 模拟终端设备，上传数据波形
        // 方法2 bindValue
        query.prepare("INSERT INTO sample (value, time, dev_id) VALUES (:array, :time, :dev_id)");
        // 与数据库中数据类型一致的十六进制数组
        short samples[3] = {2000,2001,2002};
        QByteArray waves2((char*)samples, sizeof(samples));

        query.bindValue(":array", waves2);
        // 绑定当前时间
        query.bindValue(":time", QDateTime::currentDateTime());
        // 绑定设备ID
        query.bindValue(":dev_id", dev_id);
        // 执行sql语句
        queryOk = query.exec();
        if (!queryOk)
        {
            qDebug()<<"写波形错误："<<query.lastError();
        }else{
              qDebug()<<"写波形成功";
        }

        //每15秒更新一次refresh字段，判定离线的条件是refresh中时间与当前时间差值超过20s
        query.prepare("update `medical_monitor1`.`device` set refresh = now() where dev_id =:dev_id");
        query.bindValue(":dev_id",dev_id);
        query.exec();
        if(!queryOk)
          qDebug()<<"更新设备在线状态错误";

    }
    //显示设备列表
            //创建表格对象
           QSqlQuery
         query(db);


           //创建表格对象
          // QTableView *patientView1 =new QTableView();
           //biao
             QTableView *view =new QTableView();
               Patientmodel *qwe = new Patientmodel();
           //创建模型对象
          // QSqlQueryModel *patientModel1 = new QSqlQueryModel();
         //patientModel1->setQuery("select id ,name,sex from patient");

        // patientModel1->setHeaderData(0, Qt::Horizontal, tr("id"));
       // patientModel1->setHeaderData(1, Qt::Horizontal, tr("name"));
      //  patientModel1->setHeaderData(2, Qt::Horizontal, tr("sex"));

           // model.setQuery("select dev_id,serial,now()-refresh <20 as online from device");
            view->setModel(qwe);
            view->setWindowTitle("qw");
            //view->show();

//显示病人信息列表

                    //创建表格对象
                    QTableView *patientView =new QTableView();
                    //创建模型对象
                    QSqlQueryModel *patientModel = new QSqlQueryModel();
                  patientModel->setQuery("select dev_id ,serial,refresh from device");

                  patientModel->setHeaderData(0, Qt::Horizontal, tr("devid"));
                 patientModel->setHeaderData(1, Qt::Horizontal, tr("serial"));
                 patientModel->setHeaderData(2, Qt::Horizontal, tr("refresh"));
                    //  Patientmodel *patientModel = new Patientmodel();
                    patientView->setModel(patientModel);
                    patientView->setWindowTitle("sdf");
                   // patientView->show();

                    QHBoxLayout *layout = new QHBoxLayout();
                    layout->addWidget(view);
                     layout->addWidget( patientView);
                     //加入发送端的病人信息。client
                  lineedit = new QLineEdit();
                     QPushButton *sendbtn = new QPushButton();
                     sendbtn->setText("send");
                    layout->addWidget(lineedit);
                     layout->addWidget(sendbtn);
                     this->setLayout(layout);

                     this->resize(900,300);

                     this->setWindowTitle("医生工作台");

                     //服务端



}



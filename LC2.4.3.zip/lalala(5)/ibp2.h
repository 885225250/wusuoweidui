#ifndef IBP2_H
#define IBP2_H


#include <QWidget>

class ibp2 : public QWidget
{
    Q_OBJECT
public:
    int ibp2data[125];

    int i = 0;
    int j = 0;
    explicit ibp2(QWidget *parent = nullptr);

signals:

public slots:
};
#endif // IBP2_H

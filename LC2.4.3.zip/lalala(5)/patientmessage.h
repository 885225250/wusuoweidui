#ifndef PATIENTMESSAGE_H
#define PATIENTMESSAGE_H

#include <QWidget>

#include <QWidget>
#include <QTcpSocket>
#include <QLineEdit>
class PatientMessage : public QWidget
{
    Q_OBJECT
public:
    explicit PatientMessage(QWidget *parent = nullptr);

signals:
private slots:
    void tcpReadyRead();
    void on_pushButton_clicked();
    void reconnect();

private:

    QTcpSocket *mSocket;
    QTimer *mTimer;
     QLineEdit *lineedit ;


};

#endif // PATIENTMESSAGE_H

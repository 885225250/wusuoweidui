#include "loginmode.h"

LogInMode::LogInMode(QWidget *parent) : QWidget(parent)
{

}

#ifndef SPO2_H
#define SPO2_H

#include <QWidget>
class spo2 : public QWidget
{
    Q_OBJECT
public:
      int spo2data[248];
    int j = 0;
    explicit spo2(QWidget *parent = nullptr);

signals:

public slots:
};
#endif // SPO2_H

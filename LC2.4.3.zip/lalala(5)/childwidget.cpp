#include "childwidget.h"
#include "childwidget.h"
#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include "mainwindow.h"
//#include "layoutDemo.h"
#include "qwidgetdraw.h"
#include "qwidgetserialtx.h"
#include "qwidgetserialrx.h"

ChildWidget::ChildWidget(QWidget *parent) : QWidget(parent)
{

    // 创建界面
    QWidget * mainWin = new QWidget();
    QTimer *timer;
    QVBoxLayout *vlayoutMain = new QVBoxLayout();
    timer = new QTimer(mainWin);
    timer->start(10); //单位是毫秒
    mainWin->resize(2000,1000);
    // 左侧三块儿水平label
    //心电波形图
    QWidgetDraw *drawEcg = new QWidgetDraw(mainWin);
    QWidgetSerialTx *serialEcgTx = new QWidgetSerialTx(mainWin, 0);
    QWidgetSerialRx *serialEcgRx = new QWidgetSerialRx(mainWin, 0);
    mainWin->connect(timer, &QTimer::timeout, serialEcgRx, &QWidgetSerialRx::sendEcgData);
    mainWin->connect(serialEcgRx, &QWidgetSerialRx::rxDataSignal, drawEcg, &QWidgetDraw::refreshEcgFromData);
    vlayoutMain->addWidget(drawEcg);
    //设置界面显示内容
    drawEcg->setLabelText("ecg");
    drawEcg->setStyleSheet("background-color:black; color:white; font-family:Microsoft TaHei; font-size:15px");
    //血氧波形图
    QWidgetDraw *drawSpo = new QWidgetDraw(mainWin);
    QWidgetSerialTx *serialSpoTx = new QWidgetSerialTx(mainWin, 1);
    QWidgetSerialRx *serialSpoRx = new QWidgetSerialRx(mainWin, 1);
    mainWin->connect(timer, &QTimer::timeout, serialSpoRx, &QWidgetSerialRx::sendSpoData);
    mainWin->connect(serialSpoRx, &QWidgetSerialRx::rxDataSignal, drawSpo, &QWidgetDraw::refreshSpoFromData);
    vlayoutMain->addWidget(drawSpo);
    drawSpo->setLabelText("Spo");
     drawSpo->setStyleSheet("background-color:black; color:white; font-family:Microsoft TaHei; font-size:15px");
    //血压波形图绘图控件和数据发送部分
    QWidgetDraw *drawIbp = new QWidgetDraw(mainWin);
    QWidgetSerialTx *serialIbpTx = new QWidgetSerialTx(mainWin, 2);
    QWidgetSerialRx *serialIbpRx = new QWidgetSerialRx(mainWin, 2);
    mainWin->connect(timer, &QTimer::timeout, serialIbpRx, &QWidgetSerialRx::sendIbpData);
    mainWin->connect(serialIbpRx, &QWidgetSerialRx::rxDataSignal, drawIbp, &QWidgetDraw::refreshIbpFromData);
    vlayoutMain->addWidget(drawIbp);
    drawIbp->setLabelText("Ibp");
     drawIbp->setStyleSheet("background-color:black; color:white; font-family:Microsoft TaHei; font-size:15px");
    //绘图部分的策略
    drawEcg->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
    drawSpo->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
    drawIbp->setSizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);

    //第一行
         QWidget *draw1 = new QWidget();
         //创建主界面
        QWidget *draw11 = new QWidget();
        //标题
        draw11->setWindowTitle("哈尔滨工程大学");
        //创建标签，修改显示
        QLabel *tempText = new QLabel();
        tempText->setText("ST");
        //设置父亲对象
        tempText->setParent(draw11);
         tempText->setStyleSheet("color:white;font-size: 30px");
        //设置显示位置
        tempText->setGeometry(0, 0, 300, 25);
        QLabel *tempText1 = new QLabel();
        tempText1->setText("实习奥利给");
        //设置父亲对象
        tempText1->setParent(draw11);
         tempText1->setStyleSheet("font-size: 20px");
        //设置显示位置
        tempText1->setGeometry(0, 50, 300, 50);
        QWidget *draw12 = new QWidget();
        //标题
        draw12->setWindowTitle("哈尔滨工程大学");
        //创建标签，修改显示
        QLabel *tempText12 = new QLabel();
        tempText12->setText("HR");
        //设置父亲对象
        tempText12->setParent(draw12);
         tempText12->setStyleSheet("color: white;font-size: 30px");
        //设置显示位置
        tempText12->setGeometry(0, 0, 300, 25);
        QLabel *tempText112 = new QLabel();
        tempText112->setText("bpm");
        //设置父亲对象
        tempText112->setParent(draw12);
         tempText112->setStyleSheet("font-size: 20px");
        //设置显示位置
        tempText112->setGeometry(270, 25, 30, 25);
        QLabel *tempText1121 = new QLabel();
        tempText1121->setText("80");
        //设置父亲对象
        tempText1121->setParent(draw12);
         tempText1121->setStyleSheet("font-size: 60px");
        //设置显示位置
        tempText1121->setGeometry(70, 50, 100, 100);

        QHBoxLayout *layout11 = new QHBoxLayout();
        layout11->addWidget(draw12);
        layout11->addWidget(draw11);
         draw1->setLayout(layout11);

    //第二行
        QWidget *draw5 = new QWidget();
        //标题
        draw5->setWindowTitle("哈尔滨工程大学");
        //创建标签，修改显示
        QLabel *tempText3 = new QLabel();
        tempText3->setText("NIBP");
        //设置父亲对象
        tempText3->setParent(draw5);
         tempText3->setStyleSheet("color:white;font-size: 30px");
        //设置显示位置
        tempText->setGeometry(0, 0, 300, 25);
        QLabel *tempText4 = new QLabel();
        tempText4->setText("实习奥利给");
        //设置父亲对象
        tempText4->setParent(draw5);
         tempText4->setStyleSheet("font-size: 20px");
        //设置显示位置
        tempText4->setGeometry(0, 50, 300, 50);


      //第三行
         QWidget *draw2 = new QWidget();

        QWidget *draw21 = new QWidget();
        //标题
        draw21->setWindowTitle("哈尔滨工程大学");
        //创建标签，修改显示
        QLabel *tempText51 = new QLabel();
        tempText51->setText("spO2");
        //设置父亲对象
        tempText51->setParent(draw21);
         tempText51->setStyleSheet("color:white;font-size: 30px");
        //设置显示位置
        tempText->setGeometry(0, 0, 300, 25);
        QLabel *tempText61 = new QLabel();
        tempText61->setText("84 bpm");
        //设置父亲对象
        tempText61->setParent(draw21);
         tempText61->setStyleSheet("font-size: 20px");
        //设置显示位置
        tempText61->setGeometry(230, 150, 70, 25);
        QLabel *tempText611 = new QLabel();
        tempText611->setText("90");
        //设置父亲对象
        tempText611->setParent(draw21);
         tempText611->setStyleSheet("font-size: 60px");
        //设置显示位置
        tempText611->setGeometry(70, 50, 100, 100);






        QWidget *draw22 = new QWidget();
        //标题
        draw22->setWindowTitle("哈尔滨工程大学");
        //创建标签，修改显示
        QLabel *tempText5 = new QLabel();
        tempText5->setText("TEMP");
        //设置父亲对象
        tempText5->setParent(draw22);
         tempText5->setStyleSheet("color:white;font-size: 30px");
        //设置显示位置
        tempText->setGeometry(0, 0, 300, 25);
        QLabel *tempText6 = new QLabel();
        tempText6->setText("实习奥利给");
        //设置父亲对象
        tempText6->setParent(draw22);
         tempText6->setStyleSheet("font-size: 20px");
        //设置显示位置
        tempText6->setGeometry(0, 50, 300, 50);


        QHBoxLayout *layout3 = new QHBoxLayout();
        layout3->addWidget(draw21);
        layout3->addWidget(draw22);
         draw2->setLayout(layout3);











    //第四行
        QWidget *draw3 = new QWidget();
        //标题
        draw3->setWindowTitle("哈尔滨工程大学");
        //创建标签，修改显示
        QLabel *tempText7 = new QLabel();
        tempText7->setText("RESP");
        //设置父亲对象
        tempText7->setParent(draw3);
         tempText7->setStyleSheet("color:white;font-size: 30px");
        //设置显示位置
        tempText->setGeometry(0, 0, 300, 25);
        QLabel *tempText8 = new QLabel();
        tempText8->setText("实习奥利给");
        //设置父亲对象
        tempText8->setParent(draw3);
         tempText8->setStyleSheet("font-size: 20px");
        //设置显示位置
        tempText8->setGeometry(0, 50, 300, 50);

        draw11->setStyleSheet("background-color: black; color: white; font-size: 40px");
        draw12->setStyleSheet("background-color: black; color: green; font-size: 40px");
        draw5->setStyleSheet("background-color:  black; color: white; font-size: 40px");
        draw21->setStyleSheet("background-color: black; color: red; font-size: 40px");
        draw22->setStyleSheet("background-color: black; color: white; font-size: 40px");
        draw3->setStyleSheet("background-color:  black; color: white; font-size: 40px");



        QVBoxLayout *layout2 = new QVBoxLayout();
        layout2->addWidget(draw1);
        layout2->addWidget(draw5);
        layout2->addWidget(draw2);
        layout2->addWidget(draw3);

    //总体两列水平布局
    QHBoxLayout *layout333 = new QHBoxLayout();
    layout333->addLayout(vlayoutMain);
    layout333->addLayout(layout2);
    layout333->setStretch(0, 2);
    layout333->setStretch(1, 1);
    // 上侧灰色
    QHBoxLayout *layout1111 = new QHBoxLayout();
    QLabel *label1111 = new QLabel();
    label1111->setText("新冠疫情监护仪");
    label1111->setStyleSheet("background-color:rgb(70, 70, 70); color:white; font-family:Microsoft TaHei; font-size:24px");
    layout1111->addWidget(label1111);
    // 总体布局，两行垂直
    QVBoxLayout *layout4 = new QVBoxLayout();
    layout4->addLayout(layout1111);
    layout4->addLayout(layout333);
    layout4->setStretch(0, 1);
    layout4->setStretch(1, 10);
    // 把布局器应用到界面上
    mainWin->setLayout(layout4);
    // 样式表可指定设置某一类控件，或者某个控件
    // 样式表可存入单独文件，配置时进行调取
    mainWin->setStyleSheet("background-color: grey; color: black");
    mainWin->setWindowTitle("xx队制作");
    //mainWin->show();

    QHBoxLayout *ll = new QHBoxLayout();
    ll->addWidget(mainWin);
    this->setLayout(ll);
    this->resize(2000,1000);
}

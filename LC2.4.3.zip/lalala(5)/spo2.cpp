#include "spo2.h"
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include<QTableView>
#include<QSqlQueryModel>
spo2::spo2(QWidget *parent) : QWidget(parent)
{
    // 加载驱动
    QSqlDatabase db2 = QSqlDatabase::addDatabase("QMYSQL");
    // 服务器地址，本地/远程IP/域名
    db2.setHostName("localhost");
    // 数据库名字
    db2.setDatabaseName("ecgdata");
    // 用户名+密码
    db2.setUserName("doctor3");
    db2.setPassword("123456");
    // 用open打开与数据库的连接，可用close关闭
    // 如果打开成功open会返回true，否则返回false
    bool openOk = db2.open();

    if (openOk)
        qDebug()<<"建立连接成功";
    else
    {
        qDebug()<<"建立连接失败";
    }

    // 查询一条信息
    if (openOk)
    {
        // query负责执行sql语句，db指定使用哪个连接
        QSqlQuery query(db2);

               query.exec("SELECT * from spor");
              // qDebug()<<query.size();
               while(query.next())
               {
                   spo2data[j]=query.value("spordata").toInt();
                  //   qDebug()<<"22222222222222222222222222222222" << spo2data[j];
                    QString Number = query.value("spordata").toString();
                  // QString serial = query.value("serial").toString();

                 //  qDebug()<<Number<<serial;
                  // qDebug() << acgdata[i];
                    j++;
               }
               // qDebug()<<"22222222222222222222222222222222" << spo2data[50];
       /*
               query.exec("SELECT * from ibp ");
              // qDebug()<<query.size();

               while(query.next())
               {
                   ibp2data[j]=query.value("ibp_data").toInt();

                    QString Number2 = query.value("ibp_data").toString();

                    j++;
               }
       //  qDebug() << acgdata[311];
      */

}
}

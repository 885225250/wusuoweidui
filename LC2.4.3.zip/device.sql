/*
MySQL Data Transfer
Source Host: localhost
Source Database: d1
Target Host: localhost
Target Database: d1
Date: 2020/7/25 2:34:18
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for device
-- ----------------------------
CREATE TABLE `device` (
  `dev_id` int(11) NOT NULL auto_increment,
  `serial` varchar(16) NOT NULL,
  `refresh` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`dev_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `device` VALUES ('1', 'DEV-001', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('2', 'DEV-002', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('3', 'DEV-003', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('4', 'DEV-004', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('5', 'DEV-005', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('6', 'DEV-006', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('7', 'DEV-007', '2020-07-22 17:29:16');
INSERT INTO `device` VALUES ('8', 'DEV-008', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('9', 'DEV-009', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('10', 'DEV-010', '0000-00-00 00:00:00');
INSERT INTO `device` VALUES ('11', 'DEV-011', '0000-00-00 00:00:00');
